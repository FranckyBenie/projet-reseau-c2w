#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 17 18:11:29 2018

@author: b18kouas
"""

class sendAndWait:
    def __init__(self):
        self.queue=[]
    
    def send(self,message):
        pass
    def traitemenAck(self,ack):
        pass