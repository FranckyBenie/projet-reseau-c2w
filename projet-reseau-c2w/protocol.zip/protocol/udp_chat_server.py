
# -*- coding: utf-8 -*-

from twisted.internet.protocol import DatagramProtocol

from c2w.main.lossy_transport import LossyTransport

import logging

import struct
from twisted.internet import reactor

logging.basicConfig()
import re
from c2w.main.constants import ROOM_IDS

moduleLogger = logging.getLogger('c2w.protocol.udp_chat_server_protocol')

class c2wUdpChatServerProtocol(DatagramProtocol):

    def __init__(self, serverProxy, lossPr):

        """

        :param serverProxy: The serverProxy, which the protocol must use

            to interact with the user and movie store (i.e., the list of users

            and movies) in the server.

        :param lossPr: The packet loss probability for outgoing packets.  Do

            not modify this value!


        Class implementing the UDP version of the client protocol.


        .. note::

            You must write the implementation of this class.


        Each instance must have at least the following attribute:


        .. attribute:: serverProxy


            The serverProxy, which the protocol must use

            to interact with the user and movie store in the server.


        .. attribute:: lossPr


            The packet loss probability for outgoing packets.  Do

            not modify this value!  (It is used by startProtocol.)


        .. note::

            You must add attributes and methods to this class in order

            to have a working and complete implementation of the c2w

            protocol.

        """

        #: The serverProxy, which the protocol must use

        #: to interact with the server (to access the movie list and to 

        #: access and modify the user list).

        self.serverProxy = serverProxy

        self.lossPr = lossPr
        self.numeroSeq_courant=0
        self.numeroSeq_Prec=0
        self.ack_recu=0
        self.nombre_paquet_envoye=0
        self.paquetMemoire=bytes()
        
        self.user_adress=dict()
        self.numSeq_adress=dict()
        
        self.numero_ack_recu=0
        
        self.user_List_Test=[]
        
        
        
        for movie in self.serverProxy.getMovieList():
                  movieIP=self.serverProxy.getMovieAddrPort(movie.movieTitle)[0]
                  moviePort=self.serverProxy.getMovieAddrPort(movie.movieTitle)[1]
                  movieName=movie.movieTitle
                  movieLong=len(movieName)
                  movieIP=re.findall(r"\d+",movieIP)
                  print('Movie:'+str(movieLong)+','+movieName+','+str(movieIP)+','+str(moviePort))
        

        

    #---------------------------------------------------

    # Fonction pour gerer les numeros de sequence       

    #---------------------------------------------------

        

    def NumSeq (self,numSeq):

        #on genere un numero de sequence pour chaque paquet envoyé

        #il est initialisé à 0 et incremente de 1 a chaque nouvel envoi

        #jusqu'a 8191 où il revient à 0
  

        if     numSeq==4095:

               numSeq=0

        else: 

               numSeq+=1

        return numSeq

    

    

    #--------------------------------------------------------

    # Fonction pour definir le foramts des paquets d'Ack       

    #-------------------------------------------------------- 

    

    def FormatAck(self,Type,numSeq):

        longueur=4

        entete=(Type<<28)+(numSeq<<16)+longueur

        paquet=struct.pack('!I',entete)

        return(paquet)

     

        

    #----------------------------------------------------------------

    # Fonction pour recuperer les inforamtions des paquets recu      

    #---------------------------------------------------------------- 

    

    def PaquetRecu(self, datagram):

        print(datagram)

        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)

        entete1=entete >> 28

        Type=entete1 & int('1111',2)

        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)        

        return(Type, numSeq, longueur,messageTotal)

  

    #----------------------------------------------------------------------

    # Fonction pour definir le format du paquet Acceptation de connexion      

    #----------------------------------------------------------------------      

        

    def paquetConRes(self,Type,numSeq):
        self.numeroSeq_courant=numSeq

        longueur=4   

        entete=(Type<<28)+(numSeq<<16)+longueur

        paquet=struct.pack('!I',entete)

        return(paquet)

        

   

    #-------------------------------------------------------------

    # Fonction pour recuperer les donnees du nouvel utilisateur       

    #-------------------------------------------------------------  

        

    def userData(self,datagram):

        print(datagram)

        (entete,userName)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)
        userName=userName.decode('utf-8') 

        entete1=entete >> 28

        Type=entete1 & int('1111',2)

        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)     

        print(userName)

        return(userName)
        
        
        
    #---------------------------------------------------
    #Fonction pour envoyer la liste des videos disponibles       
    #---------------------------------------------------    
    def PaquetListMovie(self):   
        movieNombre=0
        longMovieTotal=0
        paquetMovie=bytes()
        for movie in self.serverProxy.getMovieList():
                    movieIP=self.serverProxy.getMovieAddrPort(movie.movieTitle)[0]
                    moviePort=self.serverProxy.getMovieAddrPort(movie.movieTitle)[1]
                    movieName=movie.movieTitle
                    movieLong=len(movieName)
                    longMovieTotal+=movieLong
                    movieIP=re.findall(r"\d+",movieIP)
                    print('Movie:'+str(movieLong)+','+movieName+','+str(movieIP)+','+str(moviePort))
                     
                    
                    formatIP=(int(movieIP[0])<<24)+(int(movieIP[1])<<16)+(int(movieIP[2])<<8)+(int(movieIP[3]))
                    movieNombre+=1
                    paquetMovie+=struct.pack('!B'+str(len(movieName.encode('utf-8')))+'sIH',len(movieName.encode('utf-8')),movieName.encode('utf−8'),formatIP,moviePort) 
                    
        print(movieNombre)
        #movieNombrePack=struct.pack('!H',movieNombre)
        paquetTotal=paquetMovie
        
        print(paquetTotal)
        return(movieNombre,longMovieTotal,paquetTotal)
        
    
    def EnvoiListMovie(self,Type,numSeq):
        self.numeroSeq_courant=numSeq
        (nbreMovie,longMovie,movies)=self.PaquetListMovie()
        longueur=longMovie+(nbreMovie*7)+4
        print(longueur)
        print(numSeq)
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I',entete)+movies
        print(paquet)
        print('la paquet est:'+str(paquet))
        return(paquet)   
     
        
        
    #-------------------------------------------------------------------
    #Fonction pour envoyer la liste des utilisateurs        
    #-------------------------------------------------------------------
    
    
    def ListUser(self):
        paquetUserA=bytes()     
        paquetUserM=bytes() 
        
        userNombreA=0
        userNombreM=0
        longUserA=0
        longUserM=0
        
       
        for user in self.serverProxy.getUserList():               
                print("OK",ROOM_IDS.MAIN_ROOM)
                if(user.userChatRoom==ROOM_IDS.MAIN_ROOM):
                    print("OK2222",ROOM_IDS.MAIN_ROOM)
                    statut=0
                    usernameA=user.userName
                    userNombreA=userNombreA+1
                    ver=type(user.userChatRoom)
                    print('le type de room_ids est:'+str(ver))
                    longU=len(usernameA)
                    longUserA=+longU
                    
                    
                    paquetUserA+=struct.pack('!B'+str(len(usernameA.encode('utf−8')))+'sB', len(usernameA.encode('utf−8')),usernameA.encode('utf−8'),statut)   
        
#        
#        newUser=self.userData(datagram)
#        
#        newPack=struct.pack('!B'+str(len(newUser.encode('utf−8')))+'s'+str(len(statutMain.encode('utf−8')))+'s', len(newUser.encode('utf−8')),newUser.encode('utf−8'),statutMain.encode('utf−8'))  
#        print(newPack)
                    
                    
         
                else:
                    ver=type(user.userChatRoom)
                    print('le type de room_ids 2 est:'+str(ver))
                    print('la valeur de est :'+str(user.userChatRoom))
                    statut=1
                    usernameM=user.userName
                    userNombreM=userNombreM+1
                    longU=len(usernameM)
                    longUserM=+longU
                   
                    paquetUserM+=struct.pack('!B'+str(len(usernameM.encode('utf−8')))+'sB', len(usernameM.encode('utf−8')),usernameM.encode('utf−8'),statut)   
        userNbre=userNombreA+userNombreM
        longUser=longUserA+longUserM
        print('Le nombre d utilisateur est:'+str(userNbre))  
        paquetUser=paquetUserA+paquetUserM
        #userNombre=userNombreA+userNombreM
        #userNombrePack=struct.pack('!H',userNombre)
        
        print(paquetUser)
        return(longUser,userNbre, paquetUser)  
        
        
        
        
    def EnvoiUser(self,Type,numSeq):
        self.numeroSeq_courant=numSeq
        (longUser,nbreUser,users)=self.ListUser()
        longueur=longUser+(2*nbreUser)+4
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I',entete)+users
        return(paquet)
        
        
    #----------------------------------------------------------------
    # Fonction pour send & wait    
    #---------------------------------------------------------------- 
    
    def sendAndWait(self,paquet,numSeq,host_port):
        
        
        
        if (self.nombre_paquet_envoye <= 7):
            if (self.ack_recu == 0):
                self.transport.write(paquet,host_port)
                self.nombre_paquet_envoye+=1
                print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
                reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
                
            
            
            elif(self.ack_recu == 1):
                print('Le paquet a ete aquitte')
                
           
        else:
            print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
            if(self.nombre_paquet_envoye > 7):
                for user in self.user_List_Test:
                     if(user[2]==host_port):
                         self.serverProxy.updateUserChatroom(self.serverProxy.getUserByAddress(host_port).userName,ROOM_IDS.OUT_OF_THE_SYSTEM_ROOM)
                         self.serverProxy.removeUser(self.serverProxy.getUserByAddress(host_port).userName)
                         self.user_List_Test.remove(user)
                         print('l utilisateur a ete supprimé ')
                         
                for user in self.user_List_Test: 
                    
                    print('host port en cours:'+str(host_port))
                    print('host port qui va recevoir la notification:'+str(user[2]))
                    paquet=self.EnvoiUser(6,user[1]+1)
                    self.transport.write(paquet,user[2])
                    
                    
                    
                print('Le paquet envoye est perdu')
            

    

    def startProtocol(self):

        """

        DO NOT MODIFY THE FIRST TWO LINES OF THIS METHOD!!


        If in doubt, do not add anything to this method.  Just ignore it.

        It is used to randomly drop outgoing packets if the -l

        command line option is used.

        """

        self.transport = LossyTransport(self.transport, self.lossPr)

        DatagramProtocol.transport = self.transport

    def datagramReceived(self, datagram, host_port):

        """

        :param string datagram: the payload of the UDP packet.

        :param host_port: a touple containing the source IP address and port.

        

        Twisted calls this method when the server has received a UDP

        packet.  You cannot change the signature of this method.

        """

        

        print(" ".join("{:02x}".format(c) for c in datagram))

        (Type, numSeq, longueur,messageTotal)=self.PaquetRecu(datagram)

        self.seqnum=numSeq

        

        print('test avec seqnum recu:'+str(Type)+','+str(numSeq))

        

         #si le type de paquet recu n'est pas un ack on envoie un ack au client
         
        if (Type==0):
            
            for user in self.user_List_Test: 
                if(user[2]==host_port):
                     if (self.numeroSeq_Prec==numSeq):
                         if (self.numero_ack_recu !=numSeq) :
                              self.ack_recu=1
                              
                              print('ack envoye par le client')
                    
                              print('ack recu')
                              print('mise a jour de ack a true')
                              user[3]=1
                              self.numero_ack_recu=numSeq
                         
                    
                              self.nombre_envoie=0
                        
            
                     else:
                         
                          self.ack_recu=0
              
                          self.sendAndWait(self.paquetMemoire,self.numeroSeq_Prec,host_port)
                
                
            

        if(Type!=0):
            for user in self.user_List_Test:
                 if(user[2]==host_port):
                     print('message recu')

                     ack=self.FormatAck(0,numSeq)

                     print('ack envoyé au client:'+str(ack))
                     print('host port est:'+str(host_port))

                     self.transport.write(ack,host_port)
                     
                     user[0]=user[0]+1

                     print('ack bien envoyé au client avec seqnum:'+str(numSeq))
                    
            
            
            

            

        

        # si le paquet recu est une requete de connexion, on envoie un message de type 8 si la connexion a reussie

        if(Type==1 or Type==0):
            
            if (Type==1):
                 userName=self.userData(datagram)
                 
           
                 print('username test:'+str(userName))
            
#            
                 if(len(userName)>251):
                    print('pseudo trop long')
                    paquet=self.paquetConEchouee(9,0)
                    self.paquetMemoire=paquet
                    self.numeroSeq_Prec=self.numeroSeq_courant
                    self.numeroSeq_courant+=1
                    self.transport.write(paquet,host_port)
                    reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
                    self.nombre_paquet_envoye=1
                    self.ack_recu=0

                
                
                
                 elif(self.serverProxy.userExists(str(userName))):
                      paquet=self.paquetConEchouee(9,0)
                      self.paquetMemoire=paquet
                      self.numeroSeq_Prec=self.numeroSeq_courant
                      self.numeroSeq_courant+=1
                      self.transport.write(paquet,host_port)
                      reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
                      self.nombre_paquet_envoye=1
                      self.ack_recu=0
                 
               
                
                 elif not(self.serverProxy.userExists(str(userName))):
                      print('pseudo correct:connexion accepté')
      
                      self.serverProxy.addUser(userName,ROOM_IDS.MAIN_ROOM,None,host_port)
                      
                      self.numSeq_adress[userName]=numSeq
                      self.user_adress[userName]=host_port
                      self.user_List_Test.append([numSeq,userName,host_port,0,0])
                      print(self.user_List_Test)
                
                
                      self.user_adress[userName]=host_port
                      paquet=self.paquetConRes(8,0)
                
                      self.paquetMemoire=paquet
                      self.numeroSeq_Prec=self.numeroSeq_courant
                      self.numeroSeq_courant+=1
                


                      print(paquet)
                      self.transport.write(paquet,host_port)
                      reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
                      self.nombre_paquet_envoye=1
                      print('requete de connexion')
               
                
            
            if (Type==0):
                print('Le numero recu est:'+str(numSeq))
                if (numSeq==0):
                    paquet3=self.EnvoiUser(6,1)
                    self.paquetMemoire=paquet3
                    self.numeroSeq_Prec=self.numeroSeq_courant
                    self.numeroSeq_courant+=1
                    self.transport.write(paquet3,host_port)
                    reactor.callLater(1,self.sendAndWait,paquet3,numSeq,host_port)
                    self.nombre_paquet_envoye=1
                    

                if (numSeq==1):
                     paquet2=self.EnvoiListMovie(5,2)
                     self.paquetMemoire=paquet2
                     self.numeroSeq_Prec=self.numeroSeq_courant
                     self.numeroSeq_courant+=1
                     self.transport.write(paquet2,host_port)
                     reactor.callLater(1,self.sendAndWait,paquet2,numSeq,host_port)
                     self.nombre_paquet_envoye=1
                     print('LA liste des videos est :'+str(paquet2))
                   
                
                
       #---------------------------------------------------------------------------------
        if (Type==2):
              roomName=messageTotal.decode('utf-8') 
              print('Ta chambre est :'+str(roomName))
              user=self.serverProxy.getUserByAddress(host_port)
              if(user.userChatRoom==ROOM_IDS.MAIN_ROOM):
                  print('film a watch:'+roomName)
                  self.serverProxy.startStreamingMovie(roomName)
                  username = self.serverProxy.getUserByAddress(host_port).userName
                  self.serverProxy.updateUserChatroom(username,roomName)
                  print('user'+str(username))
                    
                  for user in self.serverProxy.getUserList() :
                      for j in self.user_List_Test:
                              if(user.userChatRoom == ROOM_IDS.MAIN_ROOM) :
                                      print('broadcast user Main Room')
                                  
                                      print('broadcast rst au autres utilisateurs:'+user.userName)
                                      
                                      print('host port en cours:'+str(host_port))
                                      print('host port qui va recevoir le msg de mise a jour:'+str(j[2]))
                                     
                                      paquet=self.EnvoiUser(6,j[0]+1)
                                      self.paquetMemoire=paquet
                                      self.numeroSeq_Prec=self.numeroSeq_courant
                                      self.numeroSeq_courant+=1
                                      self.transport.write(paquet,j[2]) 
                                      reactor.callLater(1,self.sendAndWait,paquet,numSeq,j[2])
                                      self.nombre_paquet_envoye=1
                              else:
                                   print('broadcast user Movie Room')
                                   paquet=self.EnvoiUser(6,j[0]+1)
                                   self.paquetMemoire=paquet
                                   self.numeroSeq_Prec=self.numeroSeq_courant
                                   self.numeroSeq_courant+=1
                                   
                                   self.transport.write(paquet,j[2])
                                   reactor.callLater(1,self.sendAndWait,paquet,numSeq,j[2])
                                   self.nombre_paquet_envoye=1
                                   
              elif(user.userChatRoom!=ROOM_IDS.MAIN_ROOM):
                    
                    self.serverProxy.updateUserChatroom(user.userName,ROOM_IDS.MAIN_ROOM)
                    for user in self.serverProxy.getUserList() :
                            for j in self.user_List_Test:
                              if(user.userChatRoom == ROOM_IDS.MAIN_ROOM) :
                                      print('broadcast main room')
                                      print('broadcast rst au autres utilisateurs:'+user.userName)
                                      
                                      print('host port en cours:'+str(host_port))
                                      print('host port qui va recevoir le bc:'+str(j[2]))
                                      
                                      paquet=self.EnvoiUser(6,j[0]+1)
                                      self.paquetMemoire=paquet
                                      self.numeroSeq_Prec=self.numeroSeq_courant
                                      self.numeroSeq_courant+=1
                                      self.transport.write(paquet,j[2])
                                      reactor.callLater(1,self.sendAndWait,paquet,numSeq,j[2])
                                      self.nombre_paquet_envoye=1
                                   
                                      
              else:
                    self.serverProxy.updateUserChatroom(user.userName,ROOM_IDS.MAIN_ROOM)
                    for user in self.serverProxy.getUserList() :
                            for j in self.user_List_Test:
                              if(user.userChatRoom == ROOM_IDS.MAIN_ROOM) :
                                  
                                      
                                         
                                      print('broadcast au autres utilisateurs:'+user.userName)
                                      
                                      print('host port en cours:'+str(host_port))
                                      print('host port qui va recevoir la notification:'+str(j[2]))
                                  
                                      paquet=self.EnvoiUser(6,numSeq+1)
                                      self.paquetMemoire=paquet
                                      self.numeroSeq_Prec=self.numeroSeq_courant
                                      self.numeroSeq_courant+=1
                                      self.transport.write(paquet,j[2])
                                      reactor.callLater(1,self.sendAndWait,paquet,numSeq,j[2])
                                      self.nombre_paquet_envoye=1
                                   
            
        #-----------------------------------------------------------------------------------
#        if (Type==4):
#              user = self.serverProxy.getUserByAddress(host_port)
#            
#              if(user.userChatRoom==ROOM_IDS.MAIN_ROOM):
#                  self.user_adress= user.userAddress
#                #user.userChatRoom=ROOM_IDS.OUT_OF_THE_SYSTEM_ROOM
#                  self.serverProxy.updateUserChatroom(user.userName,ROOM_IDS.OUT_OF_THE_SYSTEM_ROOM) 
#                  self.serverProxy.removeUser(self.serverProxy.getUserByAddress(host_port).userName)  
#                  print('Deconnexion du syteme')  
#                
#                  for users in self.user_List_Test: 
#                      if(users[2]==host_port):
#                          self.user_List_Test.remove(users) 
#                          print('user suprime de la liste')
#                          
#                          
#                          
#        if (Type==3):
#            user = self.serverProxy.getUserByAddress(host_port)
#            username = self.serverProxy.getUserByAddress(host_port).userName
#            self.stopStreamingMovie(user.userChatRoom)
#            self.serverProxy.updateUserChatroom(username,ROOM_IDS.MAIN_ROOM)     
#            print('quitte la moovie room')
#           
            
                    
                        
            
            
      
         
                
               
        
                
                
   
            

            

            

            

            

            

        pass


