#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 17 18:11:29 2018

@author: b18kouas
"""

from twisted.internet import reactor
import struct

import collections
class sendAndWait:
    def __init__(self):
        
        self.queue=[]
        self.nombre_paquet_envoye=1
        self.ack_recu=1
        self.numeroSeq_Prec=0
        self.paquet_memoire=bytes()
       
       
    def memoire(self,paquet,numSeq,nbre_Tentative):
        
        self.paquet_memoire=paquet
        self.queue.append(paquet)
        self.numeroSeq_Prec=numSeq
        self.nombre_paquet_envoye=nbre_Tentative
    
    def send(self,message,numSeq,host_port):
 
             if (self.nombre_paquet_envoye <= 7):
                 if (self.ack_recu == 0):
                      print('host-port envoi est:'+str(type(host_port)))
                      self.transport.write(message,host_port)
                      self.nombre_paquet_envoye+=1
                      print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
                      reactor.callLater(1,self.sendAndWait.send,message,numSeq,host_port)
                      
                 elif(self.ack_recu == 1):
                       print('Le paquet a ete aquitte')  
                       self.queue.pop(message)
               
             else:
                print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
                if(self.nombre_paquet_envoye > 7):
                    print('Le paquet envoye est perdu')
                    self.queue.pop(message)
  
             pass
    
    
    def traitemenAck(self,num_ack):
        
        if (self.numeroSeq_Prec==num_ack):
                self.ack_recu=1
                print('ack envoye par le serveur')
                    
                self.queue.pop(self.paquet_memoire)
                
        else:
                print('C est un doublon')
        pass
            
            
    
        
       