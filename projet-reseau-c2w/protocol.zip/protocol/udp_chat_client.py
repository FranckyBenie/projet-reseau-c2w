
# -*- coding: utf-8 -*-

from twisted.internet.protocol import DatagramProtocol

from c2w.main.lossy_transport import LossyTransport
from c2w.protocol.sendAndWait import sendAndWait
import logging

import struct
from c2w.main.constants import ROOM_IDS

logging.basicConfig()
from twisted.internet import reactor

moduleLogger = logging.getLogger('c2w.protocol.udp_chat_client_protocol')

class c2wUdpChatClientProtocol(DatagramProtocol):

    def __init__(self, serverAddress, serverPort, clientProxy, lossPr):

        """

        :param serverAddress: The IP address (or the name) of the c2w server,

            given by the user.

        :param serverPort: The port number used by the c2w server,

            given by the user.

        :param clientProxy: The clientProxy, which the protocol must use

            to interact with the Graphical User Interface.


        Class implementing the UDP version of the client protocol.


        .. note::

            You must write the implementation of this class.


        Each instance must have at least the following attributes:


        .. attribute:: serverAddress


            The IP address of the c2w server.


        .. attribute:: serverPort


            The port number of the c2w server.


        .. attribute:: clientProxy


            The clientProxy, which the protocol must use

            to interact with the Graphical User Interface.


        .. attribute:: lossPr


            The packet loss probability for outgoing packets.  Do

            not modify this value!  (It is used by startProtocol.)


        .. note::

            You must add attributes and methods to this class in order

            to have a working and complete implementation of the c2w

            protocol.

        """

        #: The IP address of the c2w server.

        self.serverAddress = serverAddress

        #: The port number of the c2w server.

        self.serverPort = serverPort

        #: The clientProxy, which the protocol must use

        #: to interact with the Graphical User Interface.

        self.clientProxy = clientProxy

        self.lossPr = lossPr
        self.queue=[]
        
        self.numeroSeq_courant=0
        self.numeroSeq_Prec=0
        self.ack_recu=0
        self.nombre_paquet_envoye=0
        self.paquetMemoire=bytes()
        self.users=[]
        self.numeroSeq_GoToMovie=0
        self.deconnexion=0
        self.quitter_room=0
        #room_user=ROOM_IDS.MAIN_ROOM
        self.sendAndWait=sendAndWait()
        

    #---------------------------------------------------

    # Fonction pour gerer les numeros de sequence       

    #---------------------------------------------------

        

    def NumSeq (self,numSeq):

        #on genere un numero de sequence pour chaque paquet envoyé

        #il est initialisé à 0 et incremente de 1 a chaque nouvel envoi

        #jusqu'a 8191 où il revient à 0

        

        if     numSeq==4095:

               numSeq=0

        else: 

               numSeq+=1

        return numSeq

    

    

    #---------------------------------------------------

    # Fonction pour definir les formats de paquet       

    #---------------------------------------------------    

    

    def FormatPaquet(self,Type,numSeq,longueur,messageTotal):

        longueur=len(messageTotal)

        entete=(Type<<12)+(numSeq<<16)+longueur

        paquet=struct.pack('!II'+str(len(messageTotal))+'s',entete, messageTotal.encode('utf−8'))

        return(paquet)

        

        

    #--------------------------------------------------------

    # Fonction pour definir le format de qu paquet de login       

    #--------------------------------------------------------

        

    def PaquetLogin(self,Type,numSeq,userName):
        self.numeroSeq_courant=numSeq

        userNamepack=struct.pack(str(len(userName.encode('utf−8')))+'s', userName.encode('utf−8'))

        longueur=len(userNamepack)+4

        entete=(Type<<28)+(numSeq<<16)+longueur

        paquet=struct.pack('!I',entete)+userNamepack       

        return(paquet)

        

        

    #----------------------------------------------------------------

    # Fonction pour recuperer les inforamtions des paquets recu      

    #----------------------------------------------------------------        

        

    def PaquetRecu(self, datagram):

        print(datagram)

        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)

        entete1=entete >> 28

        Type=entete1 & int('1111',2)

        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)     

        return(Type, numSeq, longueur,messageTotal)

        

        

    #--------------------------------------------------------

    # Fonction pour definir le foramts des paquets d'Ack       

    #--------------------------------------------------------    

        

    def FormatAck(self,Type,numSeq):

        longueur=4

        entete=(Type<<28)+(numSeq<<16)+longueur

        paquet=struct.pack('!I',entete)

        return(paquet)
        
        
        
    #----------------------------------------------------------------
    # Fonction pour recuperer la liste des utilisateurs de la Main Room      
    #---------------------------------------------------------------- 
    def PaquetUser(self, datagram):
         # on affiche le paquet recu
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))
       
        # liste des utilisateurs de la mainroom
        userList=list()
        
        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)
        print(entete)
        entete1=entete >> 28
        Type=entete1 & int('1111',2)
        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)
        
        datagram=datagram[4:]
        print('le datagram est:'+str(datagram))
        longueurMes=longueur-4
        
        while (longueurMes!=0):
        
            longName=struct.unpack('!B',datagram[0:1])[0]
            print(longName)
            datagram=datagram[1:]
            
            print('taille du nom :'+str(longName))
    
            user_name=struct.unpack(str(longName)+'s',datagram[0:longName])[0]
          
            user_name=user_name.decode('utf-8') 
            print(user_name)
            datagram=datagram[longName:]
            
            statut=struct.unpack('B',datagram[0:1])[0]
             
            print(statut)
            if (statut==0):
                statutUser=ROOM_IDS.MAIN_ROOM
            else:
                statutUser=ROOM_IDS.MOVIE_ROOM
            
            userList.append((user_name, statutUser))
            print('La longueur du nom avant est:'+str(longueurMes))
            datagram=datagram[1:]
            longueurMes=longueurMes-(2+longName)
            print('La longueur du nom apres est:'+str(longueurMes))
        print(userList)
        return(userList)
        
        
    
    #----------------------------------------------------------------
    # Fonction pour la liste des videos disponibles     
    #----------------------------------------------------------------        
        
    def PaquetMovie(self, datagram):
        
       
        # liste contenant la longueur, le nom, l adresse IP et le port des films
        movieList=list()
        
        #on separe l'entete du message en lui meme
        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)    
        entete1=entete >> 28
        Type=entete1 & int('1111',2)
        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)
        print(Type)
        print(numSeq)
        print(longueur)
        datagram=datagram[4:]
        print(datagram)
        longueurMes=longueur-4
        print(messageTotal)
        print(longueurMes)
        while (longueurMes!=0):
            
        
            longMovie=struct.unpack('!B',datagram[0:1])[0]
            print(longMovie)
            datagram=datagram[1:]
            
            print('taille du nom de film:'+str(longMovie))
    
            movie_name=struct.unpack(str(longMovie)+'s',datagram[0:longMovie])[0]
           
          
            movie_name=movie_name.decode('utf-8') 
            print(movie_name)
            datagram=datagram[longMovie:]
           
            # récuperer l'adresse ip et le port de chaque film
            adr_ip=struct.unpack('!I',datagram[0:4])[0]
            adr_ip3 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip2 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip1 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip0 = adr_ip
            ip_adress = str.join(".",(str(adr_ip0),str(adr_ip1),str(adr_ip2),str(adr_ip3)))
            print(ip_adress )
           
            datagram=datagram[4:]
            port=struct.unpack('!H',datagram[0:2])[0]
            print(port)
            
            
            # liste contenant le nom, port et l'ip du film
            movieList.append((movie_name,ip_adress ,port))
            
            datagram=datagram[2:]
            print('La longueur actuelle est :'+str(longueurMes))
            longueurMes=longueurMes-(7+longMovie)
            print(len(str(ip_adress)))
            print(len(str(port)))
            print(len(str(longMovie)))
            print('La longueur après est :'+str(longueurMes))
        print(movieList) 
        return(movieList)
        
        
    
    #----------------------------------------------------------------
    # Fonction pour aller dans une movie room      
    #---------------------------------------------------------------- 
    
    def FormatSelectMovie(self,Type,numSeq,movieName):
        self.numeroSeq_courant=numSeq
        longueur=len(movieName)+4
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I'+str(len(movieName.encode('utf-8')))+'s',entete, movieName.encode('utf−8'))
        return(paquet)
        
        
        
    
    
    #----------------------------------------------------------------
    # Fonction pour quitter la salle de video     
    #---------------------------------------------------------------- 
    def FormatLeaveRoom(self,Type,numSeq):
        self.numeroSeq_courant=numSeq
        longueur=4  
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I', entete)
        return(paquet)
    
    
        
        
        
    #----------------------------------------------------------------
    # Fonction pour send & wait    
    #---------------------------------------------------------------- 
    
#    def sendAndWait(self,paquet,numSeq,host_port):
#        
#        
#        
#        if (self.nombre_paquet_envoye <= 7):
#            if (self.ack_recu == 0):
#                print('host-port envoi est:'+str(type(host_port)))
#                self.transport.write(paquet,host_port)
#                self.nombre_paquet_envoye+=1
#                print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
#                reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
#                
#            
#            
#            elif(self.ack_recu == 1):
#                print('Le paquet a ete aquitte')
#                
#           
#        else:
#            print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
#            if(self.nombre_paquet_envoye > 7):
#                print('Le paquet envoye est perdu')
                
                
                
                

       
        

    

    def startProtocol(self):

        """

        DO NOT MODIFY THE FIRST TWO LINES OF THIS METHOD!!


        If in doubt, do not add anything to this method.  Just ignore it.

        It is used to randomly drop outgoing packets if the -l

        command line option is used.

        """

        self.transport = LossyTransport(self.transport, self.lossPr)

        DatagramProtocol.transport = self.transport

    def sendLoginRequestOIE(self, userName):

        """

        :param string userName: The user name that the user has typed.


        The client proxy calls this function when the user clicks on

        the login button.

        """

        moduleLogger.debug('loginRequest called with username=%s', userName)       

        print(userName)

        # on forme le paquet pour le requete de connexion

        paquet=self.PaquetLogin(1,0,userName)

        print(paquet)

        print(" ".join("{:02x}".format(donnee) for donnee in paquet))     

        self.username=userName

        # on envoie le paquet au serveur

        server=(self.serverAddress,self.serverPort)
        self.transport.write(paquet,server)
        
        sendAndWait.memoire(self,paquet,0,1)
        
        self.numeroSeq_courant+=1
        
        reactor.callLater(1,self.sendAndWait.send,paquet,0,server)
       

        

    def sendChatMessageOIE(self, message):

        """

        :param message: The text of the chat message.

        :type message: string


        Called by the client proxy  when the user has decided to send

        a chat messageROOM_IDS.MAIN_ROOM


        .. note::

           This is the only function handling chat messages, irrespective

           of the room where the user is.  Therefore it is up to the

           c2wChatClientProctocol or to the server to make sure that this

           message is handled properly, i.e., it is shown only by the

           client(s) who are in the same room.

        """

        pass

    def sendJoinRoomRequestOIE(self, roomName):

        """

        :param roomName: The room name (or movie title.)


        Called by the client proxy  when the user

        has clicked on the watch button or the leave button,

        indicating that she/he wants to change room.


        .. warning:

            The controller sets roomName to

            c2w.main.constants.ROOM_IDS.MAIN_ROOM when the user

            wants to go back to the main room.

        """
        print('Ta chambre est:'+str(roomName))
        server=(self.serverAddress,self.serverPort)
        #if (roomName==ROOM_IDS.MAIN_ROOM):
        paquet=self.FormatSelectMovie(2,self.numeroSeq_courant,roomName)
        self.numeroSeq_GoToMovie=self.numeroSeq_courant
        print(paquet)
        self.transport.write(paquet,server) 
        sendAndWait.memoire(self,paquet,self.numeroSeq_courant,1)
        numero=self.numeroSeq_courant
        self.numeroSeq_courant+=1
        
        reactor.callLater(1,self.sendAndWait.send,paquet,numero,self.serverPort)
       # self.nombre_paquet_envoye=1
#             
#        else:
#             paquet=self.FormatLeaveRoom(3,self.numeroSeq_courant)
#             self.quitter_room=self.numeroSeq_courant
#        
#             print(paquet)
#             self.transport.write(paquet,server) 
#             self.paquetMemoire=paquet
#             self.numeroSeq_Prec=self.numeroSeq_courant
#             self.numeroSeq_courant+=1
#        
#             reactor.callLater(1,self.sendAndWait,paquet,self.numeroSeq_Prec,self.serverPort)
#             self.nombre_paquet_envoye=1
            
        
        
        
        
        
       


        pass

    def sendLeaveSystemRequestOIE(self):

        """

        Called by the client proxy  when the user

        has clicked on the leave button in the main room.

        """
        
#        server=(self.serverAddress,self.serverPort)
#        paquet=self.FormatLeaveRoom(4,self.numeroSeq_courant)
#        self.deconnexion=self.numeroSeq_courant
#        
#        print(paquet)
#        self.transport.write(paquet,server) 
#        self.paquetMemoire=paquet
#        self.numeroSeq_Prec=self.numeroSeq_courant
#        self.numeroSeq_courant+=1
#        
#        reactor.callLater(1,self.sendAndWait,paquet,self.numeroSeq_Prec,self.serverPort)
#        self.nombre_paquet_envoye=1

        pass

    def datagramReceived(self, datagram, host_port):

        """

        :param string datagram: the payload of the UDP packet.

        :param host_port: a touple containing the source IP address and port.


        Called **by Twisted** when the client has received a UDP

        packet.

        """

        #on recupere les informations du paquet recu
        print('New msg recu')
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))
        

        (Type,numSeq,longueur,messageTotal)=self.PaquetRecu(datagram)

        self.seqnum=numSeq
         

        #si le paquet recu est ack on l'affiche self.quitter_room

        if (Type==0):
            
             print('Voici ce que tu ne vois pas depuis la:')
            
             sendAndWait.traitemenAck(self,numSeq)
            
             if(self.numeroSeq_GoToMovie==numSeq) and (self.numeroSeq_GoToMovie!=0):
                    print('joinRoomOKONE') 
                    self.clientProxy.joinRoomOKONE()
                    self.numeroSeq_GoToMovie=0
      
#                if (self.deconnexion==numSeq ):
#                    if (self.deconnexion!=0):
#                        self.clientProxy.leaveSystemOKONE()
#                        print('la user est suprime')
                       
            

        #sinon on envoie un ack au serveur   

        if(Type!=0):

            print('message recu')

            ack=self.FormatAck(0,numSeq)

            print('ack envoyé au serveur:'+str(ack))

            self.transport.write(ack,host_port)

            print('ack bien envoyé au serveur avec seqnum:'+str(numSeq))
            
            
        if (Type==6):
            
            if(numSeq==1):
         
                userList=self.PaquetUser(datagram)
              
                self.users=userList
                
                print('la liste :'+str(self.users))
          #print('pardon affiche toi:'+str(self.users)) 
          
            elif (numSeq>1):
                userList=self.PaquetUser(datagram)
              
                self.users=userList
                
                self.clientProxy.setUserListONE(self.users)
            
        
        if(Type==5):  
            movieList=self.PaquetMovie(datagram)
            print('la liste des videos est:'+str(movieList))
            print('la liste est:'+str(self.users))
            self.clientProxy.initCompleteONE(self.users,movieList)
            
            print(movieList)
           

        pass


