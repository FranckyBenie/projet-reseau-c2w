# -*- coding: utf-8 -*-
from twisted.internet.protocol import Protocol
import logging
import struct
logging.basicConfig()
moduleLogger = logging.getLogger('c2w.protocol.tcp_chat_client_protocol')


class c2wTcpChatClientProtocol(Protocol):

    def __init__(self, clientProxy, serverAddress, serverPort):
        """
        :param clientProxy: The clientProxy, which the protocol must use
            to interact with the Graphical User Interface.
        :param serverAddress: The IP address (or the name) of the c2w server,
            given by the user.
        :param serverPort: The port number used by the c2w server,
            given by the user.

        Class implementing the UDP version of the client protocol.

        .. note::
            You must write the implementation of this class.

        Each instance must have at least the following attribute:

        .. attribute:: clientProxy

            The clientProxy, which the protocol must use
            to interact with the Graphical User Interface.

        .. attribute:: serverAddress

            The IP address of the c2w server.

        .. attribute:: serverPort

            The port number used by the c2w server.

        .. note::
            You must add attributes and methods to this class in order
            to have a working and complete implementation of the c2w
            protocol.
        """

        #: The IP address of the c2w server.
        self.serverAddress = serverAddress
        #: The port number used by the c2w server.
        self.serverPort = serverPort
        #: The clientProxy, which the protocol must use
        #: to interact with the Graphical User Interface.
        self.clientProxy = clientProxy
        
    def NumSeq (self,numSeq):
        #on genere un numero de sequence pour chaque paquet envoyé
        #il est initialisé à 0 et incremente de 1 a chaque nouvel envoi
        #jusqu'a 8191 où il revient à 0
        
        if     numSeq==8191:
               numSeq=0
        else: 
               numSeq+=1
        return numSeq
    
    
    def ConstEntete(self,Type,numSeq,longueur,messageTotal):
        longueur=len(messageTotal)
        entete=(Type<<12)+(numSeq<<16)+longueur
        Type=entete >> 12
        numSeq=entete & int('0000111111111111',2) 
        longueur=entete << 28
        
        return (Type, numSeq,longueur)
        
      
    
    def PreparePaquet(self,Type,numSeq,longueur,messageTotal):
        longueur=len(messageTotal)
        entete=(Type<<12)+(numSeq<<16)+longueur
        paquet=struct.pack('>ii'+str(len(messageTotal))+'s',entete, messageTotal.encode('utf−8'))
        return(paquet)
        
        
    def PaquetLogin(self,Type,numSeq,longueur,userName):
        userNamepack=struct.pack('>hh'+str(len(userName.encode('utf−8')))+'s',len(userName.encode('utf−8')),userName.encode('utf−8'))
        entete=(Type<<12)+(numSeq<<16)+longueur
        paquet=struct.pack('>ii',entete)+userNamepack
        return(paquet)
        
    
        
        
    def PaquetSansMsg(self, datagram):
        (entete, messageTotal)=struct.unpack('>ii'+str(len(datagram)-8)+'s',datagram)
        Type,numSeq,longueur=0,0,0
        tmp=self.ConstEntete(Type,numSeq,longueur,messageTotal)
        Type=tmp[0]
        numSeq=tmp[1]
        longueur=tmp[2]
        return(Type, numSeq, longueur)
    

    def sendLoginRequestOIE(self, userName):
        """
        :param string userName: The user name that the user has typed.

        The client proxy calls this function when the user clicks on
        the login button.
        """
        moduleLogger.debug('loginRequest called with username=%s', userName)
        print(userName)
        
        longueur=len(("1")+("1")+("0")+(userName))
        datagram=self.PaquetLogin(1,1,0,longueur,userName)
        print(datagram)
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))
        self.username=userName
        self.transport.write(datagram)
        

    def sendChatMessageOIE(self, message):
        """
        :param message: The text of the chat message.
        :type message: string

        Called by the client proxy when the user has decided to send
        a chat message

        .. note::
           This is the only function handling chat messages, irrespective
           of the room where the user is.  Therefore it is up to the
           c2wChatClientProctocol or to the server to make sure that this
           message is handled properly, i.e., it is shown only by the
           client(s) who are in the same room.
        """
        pass

    def sendJoinRoomRequestOIE(self, roomName):
        """
        :param roomName: The room name (or movie title.)

        Called by the client proxy  when the user
        has clicked on the watch button or the leave button,
        indicating that she/he wants to change room.

        .. warning:
            The controller sets roomName to
            c2w.main.constants.ROOM_IDS.MAIN_ROOM when the user
            wants to go back to the main room.
        """
        pass

    def sendLeaveSystemRequestOIE(self):
        """
        Called by the client proxy  when the user
        has clicked on the leave button in the main room.
        """
        pass
    
    def Data(self, data):
        datagram=data
        
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))
        #on decode le paquet recu du serveur
        (Type,numSeq,longueur,messageTotal)=self.PaquetSansMessage(datagram)
        #on recupere le numero de sequence du paquet recu
        self.seqnum=numSeq
        
        

    def dataReceived(self, data):
        """
        :param data: The data received from the client (not necessarily
                     an entire message!)

        Twisted calls this method whenever new data is received on this
        connection.
        """
        
        pass
