# -*- coding: utf-8 -*-
from twisted.internet.protocol import DatagramProtocol
from c2w.main.lossy_transport import LossyTransport
from twisted.internet import reactor

import logging
import struct

logging.basicConfig()
moduleLogger = logging.getLogger('c2w.protocol.udp_chat_client_protocol')



class c2wUdpChatClientProtocol(DatagramProtocol):
    

    def __init__(self, serverAddress, serverPort, clientProxy, lossPr):
        """
        :param serverAddress: The IP address (or the name) of the c2w server,
            given by the user.
        :param serverPort: The port number used by the c2w server,
            given by the user.
        :param clientProxy: The clientProxy, which the protocol must use
            to interact with the Graphical User Interface.

        Class implementing the UDP version of the client protocol.

        .. note::
            You must write the implementation of this class.

        Each instance must have at least the following attributes:

        .. attribute:: serverAddress

            The IP address of the c2w server.

        .. attribute:: serverPort

            The port number of the c2w server.

        .. attribute:: clientProxy

            The clientProxy, which the protocol must use
            to interact with the Graphical User Interface.

        .. attribute:: lossPr

            The packet loss probability for outgoing packets.  Do
            not modify this value!  (It is used by startProtocol.)

        .. note::
            You must add attributes and methods to this class in order
            to have a working and complete implementation of the c2w
            protocol.
        """

        #: The IP address of the c2w server.
        self.serverAddress = serverAddress
        #: The port number of the c2w server.
        self.serverPort = serverPort
        #: The clientProxy, which the protocol must use
        #: to interact with the Graphical User Interface.
        self.clientProxy = clientProxy
        self.lossPr = lossPr
        
        self.nombre_paquet_envoye=0
        self.ack_recu = 0
        
        self.numeroSeq_courant=0
        self.numeroSeq_precedent=0
        
        
        self.deconnexion=4
        self.users=[]
        
        
        
    def startProtocol(self):
        """
        DO NOT MODIFY THE FIRST TWO LINES OF THIS METHOD!!

        If in doubt, do not add anything to this method.  Just ignore it.
        It is used to randomly drop outgoing packets if the -l
        command line option is used.
        """
        self.transport = LossyTransport(self.transport, self.lossPr)
        DatagramProtocol.transport = self.transport
        
    #---------------------------------------------------
    # Fonction pour gerer les numeros de sequence       
    #---------------------------------------------------
        
    def NumSeq (self,numSeq):
        #on genere un numero de sequence pour chaque paquet envoyé
        #il est initialisé à 0 et incremente de 1 a chaque nouvel envoi
        #jusqu'a 8191 où il revient à 0
        
        if     numSeq==4095:
               numSeq=0
        else: 
               numSeq+=1
        return numSeq
    
    

    #---------------------------------------------------
    # Fonction pour definir les formats de paquet       
    #---------------------------------------------------    
    
    def FormatPaquet(self,Type,numSeq,longueur,messageTotal):
        longueur=len(messageTotal)
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!II'+str(len(messageTotal))+'s',entete, messageTotal.encode('utf−8'))
        return(paquet)
        
        
    #--------------------------------------------------------
    # Fonction pour definir le format de qu paquet de login       
    #--------------------------------------------------------
        
    def PaquetLogin(self,Type,numSeq,userName):
        self.numeroSeq_courant=numSeq
        userNamepack=struct.pack(str(len(userName.encode('utf−8')))+'s', userName.encode('utf−8'))
        longueur=len(userNamepack)+2
        entete=(Type<<28)+(numSeq<<16)+longueur
        print(longueur)
        paquet=struct.pack('!I',entete)+userNamepack  
        
        return(paquet)
        
        
    #----------------------------------------------------------------
    # Fonction pour recuperer les inforamtions des paquets recu      
    #----------------------------------------------------------------        
        
    def PaquetRecu(self, datagram):
        print(datagram)
        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)
        entete1=entete >> 28
        Type=entete1 & int('1111',2)
        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2) 
        return(Type, numSeq, longueur,messageTotal)
        
        
    
        
    #--------------------------------------------------------
    # Fonction pour definir le foramts des paquets d'Ack       
    #--------------------------------------------------------    
        
    def FormatAck(self,Type,numSeq):
        longueur=len(str(Type))+len(str(numSeq))
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I',entete)
        return(paquet)
    
    
    #----------------------------------------------------------------
    # Fonction pour la liste des videos disponibles     
    #----------------------------------------------------------------        
        
    def PaquetMovie(self, datagram):
        
       
        # liste contenant la longueur, le nom, l adresse IP et le port des films
        movieList=list()
        
        #on separe l'entete du message en lui meme
        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)    
        entete1=entete >> 28
        Type=entete1 & int('1111',2)
        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)
        print(Type)
        print(numSeq)
        print(longueur)
        datagram=datagram[4:]
        print(datagram)
        
        nbre_movie=struct.unpack('!H',datagram[0:2])[0]
        print(nbre_movie)
       
        datagram=datagram[2:]
        print(datagram)
        for i in range (nbre_movie) :
            longMovie=struct.unpack('!B',datagram[0:1])[0]
            print(longMovie)
            datagram=datagram[1:]
            
            print('taille du nom de film:'+str(longMovie))
    
            movie_name=struct.unpack(str(longMovie)+'s',datagram[0:longMovie])[0]
          
            movie_name=movie_name.decode('utf-8') 
            print(movie_name)
            datagram=datagram[longMovie:]
           
            # récuperer l'adresse ip et le port de chaque film
            adr_ip=struct.unpack('!I',datagram[0:4])[0]
            adr_ip3 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip2 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip1 = adr_ip & 255
            adr_ip = adr_ip >> 8
            adr_ip0 = adr_ip
            ip_adress = str.join(".",(str(adr_ip0),str(adr_ip1),str(adr_ip2),str(adr_ip3)))
            print(ip_adress )
           
            datagram=datagram[4:]
            port=struct.unpack('!H',datagram[0:2])[0]
            print(port)
            
            # liste contenant le nom, port et l'ip du film
            movieList.append((movie_name,ip_adress ,port))
            
            datagram=datagram[2:]
        print(movieList) 
        return(movieList)
        
    #----------------------------------------------------------------
    # Fonction pour recuperer la liste des utilisateurs de la Main Room      
    #---------------------------------------------------------------- 
    def PaquetUser(self, datagram):
         # on affiche le paquet recu
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))
       
        # liste des utilisateurs de la mainroom
        userList=list()
        
        (entete,messageTotal)=struct.unpack('!I'+str(len(datagram)-4)+'s',datagram)
        print(entete)
        entete1=entete >> 28
        Type=entete1 & int('1111',2)
        entete2=entete >>  16
        numSeq=entete2 & int('0000111111111111',2)
        longueur=entete & int('1111111111111111',2)
        datagram=datagram[4:]
        print(datagram)
        
        longueurMes=len(messageTotal)
        while (longueurMes!=0):
        
            longName=struct.unpack('!B',datagram[0:1])[0]
            print(longName)
            datagram=datagram[1:]
            
            print('taille du nom :'+str(longName))
    
            user_name=struct.unpack(str(longName)+'s',datagram[0:longName])[0]
          
            user_name=user_name.decode('utf-8') 
            print(user_name)
            datagram=datagram[longName:]
            
            statut=struct.unpack('B',datagram[0:1])[0]
            statut=statut.decode('utf-8') 
            print(statut)
            if (statut==0):
                statutUser='A'
            else:
                statutUser='M'
            
            userList.append((user_name,statutUser))
            datagram=datagram[1:]
        print(userList)
        return(userList)
        
        
    #----------------------------------------------------------------
    # Fonction pour aller dans une movie room      
    #---------------------------------------------------------------- 
    
    def FormatSelectMovie(self,Type,numSeq,movieName):
        self.numeroSeq_courant=numSeq
        longueur=len(movieName)+len(str(2))+len(str(numSeq))
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I'+str(len(movieName.encode('utf-8')))+'s',entete, movieName.encode('utf−8'))
        return(paquet)
        
    #----------------------------------------------------------------
    # Fonction pour les messages     
    #---------------------------------------------------------------- 
    def FormatMessage(self,numSeq,userName,message):
        self.numeroSeq_courant=numSeq
        
        userNamePack=struct.pack('!B'+str(len(userName.encode('utf−8')))+'s',len(userName.encode('utf−8')),userName.encode('utf−8'))
        messagePack=struct.pack(+str(len(message.encode('utf−8')))+'s',message.encode('utf−8'))
        messageTotal=userNamePack+messagePack
        longMessageTotal=len(userName)+len(message)
        longueur=len(longMessageTotal)+len(str(7))+len(str(numSeq))  
        entete=(7<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I', entete)+messageTotal
        return(paquet)
    
    #----------------------------------------------------------------
    # Fonction pour quitter la salle de video     
    #---------------------------------------------------------------- 
    def FormatLeaveRoom(self,Type,numSeq):
        self.numeroSeq_courant=numSeq
        longueur=4  
        entete=(Type<<28)+(numSeq<<16)+longueur
        paquet=struct.pack('!I', entete)
        return(paquet)
    
    
    #----------------------------------------------------------------
    # Fonction pour send & wait    
    #---------------------------------------------------------------- 
    
    def sendAndWait(self,paquet,numSeq,host_port):
        
        numSeq=self.numeroSeq_courant
        
        if (self.nombre_paquet_envoye <= 7):
            if (self.ack_recu == 0):
                self.transport.write(paquet,host_port)
                self.nombre_paquet_envoye+=1
                print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
                reactor.callLater(1,self.sendAndWait,paquet,numSeq,host_port)
                
            
            
            elif(self.ack_recu == 1):
                print('Le paquet a ete aquitte')
                
           
        else:
            print('nombre de message envoye:'+str(self.nombre_paquet_envoye))
            if(self.nombre_paquet_envoye > 7):
                print('Le paquet envoye est perdu')
            
    
    
    

    def sendLoginRequestOIE(self, userName):
        """
        :param string userName: The user name that the user has typed.

        The client proxy calls this function when the user clicks on
        the login button.
        """
        moduleLogger.debug('loginRequest called with username=%s', userName)       
        print(userName)
        
        # on forme le paquet pour le requete de connexion
        datagram=self.PaquetLogin(1,0,userName)
        print(datagram)
        print(" ".join("{:02x}".format(donnee) for donnee in datagram))     
        self.username=userName
        self.numSeq=0
        # on envoie le paquet au serveur
        server=(self.serverAddress,self.serverPort)
        self.transport.write(datagram,server)
        print('Numero de sequence Login:'+str(self.numeroSeq_courant))
        self.numeroSeq_courant=self.NumSeq(self.numeroSeq_courant)
        print('Numero de sequence Login after:'+str(self.numeroSeq_courant))
        self.ack_recu=0
        reactor.callLater(1,self.sendAndWait,datagram,self.numSeq,server)
        
        
        

    def sendChatMessageOIE(self, message):
        """
        :param message: The text of the chat message.
        :type message: string

        Called by the client proxy  when the user has decided to send
        a chat message

        .. note::
           This is the only function handling chat messages, irrespective
           of the room where the user is.  Therefore it is up to the
           c2wChatClientProctocol or to the server to make sure that this
           message is handled properly, i.e., it is shown only by the
           client(s) who are in the same room.
        """
        
        
        #numSeq=self.numeroSeq_courant
        server=(self.serverAddress,self.serverPort)
       
        print('personne a qui on envoie le message:'+str(self.userName))
         
        
        datagram=self.FormatMessage(self.numeroSeq_courant,self.userName,message)
        print(datagram)
        self.transport.write(datagram,server)
        print('Numero de sequence message:'+str(self.numeroSeq_courant))
        self.numeroSeq_courant=self.NumSeq(self.numeroSeq_courant)
        self.ack_recu=0
        reactor.callLater(1,self.sendAndWait,datagram,self.numeroSeq_courant,server)
        
        pass

    def sendJoinRoomRequestOIE(self, roomName):
        """
        :param roomName: The room name (or movie title.)

        Called by the client proxy  when the user
        has clicked on the watch button or the leave button,
        indicating that she/he wants to change room.

        .. warning:
            The controller sets roomName to
            c2w.main.constants.ROOM_IDS.MAecuIN_ROOM when the user
            wants to go back to the main room.
        """
        server=(self.serverAddress,self.serverPort)
        
       
        print('numero de sequence envoyé au serveur pour acceder a la movie room:'+str(self.numeroSeq_courant))
       
        self.selectedRoom=roomName
        datagram=self.FormatSelectMovie(2,self.numeroSeq_courant,roomName)
        print(datagram)
        self.transport.write(datagram,server) 
        print('Numero de sequence go to movie:'+str(self.numeroSeq_courant))
        self.numeroSeq_courant=self.NumSeq(self.numeroSeq_courant)
        self.nombre_paquet_envoye=0
        self.ack_recu=0 
        reactor.callLater(1,self.sendAndWait,datagram,self.numeroSeq_courant,server)
        
        pass

    def sendLeaveSystemRequestOIE(self):
        """
        Called by the client proxy  when the user
        has clicked on the leave button in the main room.
        """
        
        server=(self.serverAddress,self.serverPort)
        
        numSeq=self.numeroSeq_courant  
        #self.deconnexion=numSeq+1
        
       
        
        datagram=self.FormatLeaveRoom(numSeq)
        print(datagram)
        self.transport.write(datagram,server)
        print('Numero de sequence quitter:'+str(self.numeroSeq_courant))
        self.numeroSeq_courant=self.NumSeq(self.numeroSeq_courant)
        self.ack_recu=0 
        reactor.callLater(1,self.sendAndWait,datagram,numSeq,server)
        pass

    def datagramReceived(self, datagram, host_port):
        """
        :param string datagram: the payload of the UDP packet.
        :param host_port: a touple containing the source IP address and port.

        Called **by Twisted** when the client has received a UDP
        packet.
        """
        #on recupere les informations du paquet recu
        #print(" ".join("{:02x}".format(donnee) for donnee in datagram))
        (Type,numSeq,longueur,messageTotal)=self.PaquetRecu(datagram)
        self.seqNum=numSeq
       
        
               #---------------------------------------------------------------------------------------------------------------       
        #si le paquet recu est ack on l'affiche
        
        if(Type==0):    
            self.ack_recu=1
            print('ack envoye par le serveur:'+str(Type)+','+str(self.seqNum)+','+str(longueur)+','+str(messageTotal))
#            if (self.seqSelectMovie==self.seqNum):
#                print('joinRoomOKONE')
#                self.clientProxy.joinRoomOKONE()
#                self.seqSelectMovie=0
#            elif(self.deconnexion==self.seqNum):
#                self.clientProxy.leaveSystemOKONE()
                
        #sinon on envoie un ack au serveur 
        else:   
            ack=self.FormatAck(0,self.seqNum)
            self.transport.write(ack,host_port) 
            print('ack bien envoyé au serveur')
            
            
        #-------------------------------------------------------------------------------------------------------    
        if(Type==9):
            
            print('La connexion a echoue')
            erreur='La connexion a echoue'
            self.clientProxy.connectionRejectedONE(erreur)
           
           
        #--------------------------------------------------------------------------------------------------------------- 
        
        if(Type==8):
            print('numSeq du message envoye par le serveur:'+str(self.seqNum))
            print('la connexion a été établit')    
        #---------------------------------------------------------------------------------------------------------------
        if Type==5 :
          
                userList=self.PaquetUser(datagram)
               
                
                self.users=userList
                
                print('la liste :'+str(self.users))
        print('pardon affiche toi:'+str(self.users))       
#     
#            elif self.seqNum>1:
#                self.userList=self.PaquetUser(datagram)
#                
#                self.clientProxy.setUserListONE(self.userList)
        
        #---------------------------------------------------------------------------------------------------------------
        
               
        if(Type==6):  
            movieList=self.PaquetMovie(datagram)
            Listusers=self.users
            print('la liste est:'+str(Listusers))
            self.clientProxy.initCompleteONE(self.users,movieList)
            
            print(movieList)
        
        
        
        
        
        #---------------------------------------------------------------------------------------------------------------
        
               
#       if(Type==7):
#             (header1,header2,id_user,usernamesize,message)=struct.unpack('>IIHH'+str(len(datagram)-12)+'s',datagram)
#             for user in self.userdata:
#                 if(user[0]==id_user):
#                     print('user envoyant le message trouvé avec id:',str(user[0]),str(user[1]))
#                     
#                     self.clientProxy.chatMessageReceivedONE(user[1], message.decode('utf-8')) 
           
        pass
    
    
    
    
    
    
    
